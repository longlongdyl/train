create view v_dept_emp as
select `e`.`ENAME`    AS `ename`,
       `d`.`DNAME`    AS `dname`,
       `e`.`SAL`      AS `sal`,
       `e`.`HIREDATE` AS `hiredate`,
       `e`.`DEPTNO`   AS `deptno`
from `sh2004`.`emp` `e`
       join `sh2004`.`dept` `d`
where ((`e`.`DEPTNO` = `e`.`DEPTNO`) and (`e`.`DEPTNO` = 10));

